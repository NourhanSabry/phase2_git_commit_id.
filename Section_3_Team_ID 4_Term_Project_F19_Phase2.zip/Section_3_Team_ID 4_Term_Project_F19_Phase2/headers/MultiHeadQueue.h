#ifndef MULTIHEADQUEUE_H
#define MULTIHEADQUEUE_H

#include <includes.h>
#include <defines.h>
#include <vector>
#include <thread>

using namespace std;
template <typename T>
class MultiHeadQueue: private std::vector<T>{
    
    private:
        mutex mtx;
    public:
        MultiHeadQueue ():vector<T>(){
        }
        void enqueue(T & t)
        {
            mtx.lock();
            vector<T>::push_back(t);
            mtx.unlock();
        }
        bool dequeue(T & t,std::function <bool (T&,T&)> check)
        {
            mtx.lock();
            T e;
            for (auto x = vector<T>::begin() ;x != vector<T>::end();x++)
            {
                 
	if (check(x[0],t)) {
 	vector<T>::erase(x);
   	return true ;
            }
            mtx.unlock();
            return false;;
        }
        }
        void dump (char * filename,char * p_key_file,char * p_iv_file)
        {
mtx.lock();
     //key and iv setup
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    //Stream class to write the file
 ofstream f;
    f.open(p_key_file,ios::out); // 	Open for output operations
    T*buffer=(T*) calloc (vector<T>:: size()*sizeof(T)); // we allocates memory at runtime and
    // takes the number of vector<T> and the size of each T.
    buffer= vector <T>::data(); // the buffer will have the dada that exists in vector<T>
    long buffer_size= vector <T>:: size()*sizeof(T); // the size of vecor<T>will be stored in bufffer_size
    // stream class to read the file 
    ifstream kf_f;
        kf_f.open(p_key_file,ios::in); // open for input .

    if ( kf_f.is_open())
    {
        kf_f.read (reinterpret_cast<char*>(key),sizeof(key)); // read the key
    
    }
    // stream class to read  the file 
        ifstream iv_f;

  iv_f.open(p_iv_file,ios::in); // open for input 
    if ( iv_f.is_open())
    {
        iv_f.read (reinterpret_cast<char*>(iv),sizeof(iv)); // read the iv
        
    }
    // encryption
     encrypt(key,iv,buffer,buffer_size);
       // open the file and write the file
     if (f.is_open())
     {
         f.write(reinterpret_cast<char*>(buffer),buffer_size); // write the buffer
         
     }
     // close the file and the iv and the key files
      f.close();
      iv_f.close();
      kf_f.close();
        
        }
        void load (char * filename,char * p_key_file,char * p_iv_file)
        { 
            // filename has the que encrypted
            mtx.lock();
             // stream class to read the file
            ifstream f;
            f.open(filename,ios::in); // open the file for input operation
            if ( f.is_open())
            {
                 // decrypt first then read into the buffer
                f.seekg(0,f.end);
                long sz = f.tellg();
                f.seekg(0,f.beg);
                T * buffer = (T *) calloc(sz/sizeof(T),sizeof(T));
                f.read (reinterpret_cast<char*>(buffer),sz);
                f.close();

                // key and iv setup

	CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    	memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    	memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
// redin the key  	
      ifstream kf;
    	kf.open(p_key_file,ios::in);
    	if ( kf.is_open())
    	{
        	kf.read (reinterpret_cast<char*>(key),sizeof(key));
        	
    	}
        // read the iv
         	ifstream iv_f;
             iv_f.open(p_iv_file,ios :: in) ;
            if ( iv_f.is_open())
    	{
        	iv_f.read (reinterpret_cast<char*>(iv),sizeof(iv));
        	
    	}
        // decryption
          decrypt (key,iv,buffer,sz);
             
 
               sz/=sizeof(T);
                for ( int i = 0 ; i < sz ; i++)
                    vector<T>::push_back(buffer[i]);
                free (buffer);
                iv_f.close();
            
            kf.close();
            mtx.unlock();
        }
        ~MultiHeadQueue(){}
};



#endif
