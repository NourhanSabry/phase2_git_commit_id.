#include <ShredThread.h>

ShredThread::ShredThread (FileSpooler * p_fileSpooler,  char * p_key_file_name,  char * p_iv_file_name, const char * p_file_name,uint16_t block_size,MultiHeadQueue  <sb_block_index_t> * p_multiHeadQueue,char p_shred_name,bool truncate):Thread(), Shred(p_file_name,block_size,truncate)
{
        srcFileSpooler = p_fileSpooler;
        key_file_name = p_key_file_name;
        iv_file_name = p_iv_file_name;
        multiHeadQueue = p_multiHeadQueue;
        shred_name = p_shred_name;
}
void ShredThread::mainThreadBody(){}
ShredThread::~ShredThread(){}

EncryptShredThread::EncryptShredThread (FileSpooler * p_fileSpooler,  char * p_key_file_name,  char * p_iv_file_name,const char * p_file_name,uint16_t block_size,Lottery * p_lottery,MultiHeadQueue  <sb_block_index_t> * p_multiHeadQueue,char p_shred_name,bool truncate) : ShredThread(p_fileSpooler, p_key_file_name, p_iv_file_name,p_file_name,block_size,p_multiHeadQueue,p_shred_name,truncate)
{
    lottery = p_lottery;
}
void EncryptShredThread::mainThreadBody()
{
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    
    ifstream kf;
    kf.open(key_file_name,ios::in);
    if ( kf.is_open())
    {
        kf.read (reinterpret_cast<char*>(key),sizeof(key));
        kf.close();
    }

    prng.GenerateBlock(iv,sizeof(iv));

    ofstream f;
    f.open(iv_file_name.c_str(),ios::out|ios::trunc);
    if ( f.is_open())
    {
        f.write (reinterpret_cast<const char*>(iv),sizeof(iv));
        f.close();
    }
    //  what we want to do here ro encrypt the  acquired the block number and withdraw it from the lottry and then read what is in it 
    //and delte it in order to avoid anyway loose ends that a potential attacker may use to a4ccess
 // call the function withdraw from the lottery 
      long block_index  = lottery->withdraw();
    for (int i = 0 ;block_index!= -1; i ++)
    {
        
        Block *block =(*srcFileSpooler[block_index])
        // we used the a dereferenced pointer in order to  retrieve all the ojects in the block 

        *(this)<<*block;
        // encryption of the block
        block->encrypt(key,iv);
        sb_block_index_t s;
        s.block=block_index;
        s.shred_block=i;
        s_shred=shred_name;
         // call the function enqueue from multiHeadQueue
        multiHeadQueue->enqueue(block_index);
        // deete the block
         delete (block);
         // call the function withdraw from the lottry
       block_index  = lottery->withdraw(); 
    }
       
}
EncryptShredThread::~EncryptShredThread()
{

}

DecryptShredThread::DecryptShredThread (FileSpooler * p_fileSpooler,  char * p_key_file_name,  char * p_iv_file_name,const char * p_file_name,uint16_t block_size,MultiHeadQueue  <sb_block_index_t> * p_multiHeadQueue,char p_shred_name,bool truncate): ShredThread(p_fileSpooler, p_key_file_name, p_iv_file_name,p_file_name,block_size,p_multiHeadQueue,p_shred_name,truncate)
{
    

}
Block * DecryptShredThread::operator [] (int index)
{
    return (*fileSpooler)[index];
}

void DecryptShredThread::mainThreadBody()
{
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    ifstream f;
    f.open(key_file_name,ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(key),sizeof(key));
        f.close();
    }
    
    f.open(iv_file_name.c_str(),ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(iv),sizeof(iv));
        f.close();
    }

         sb_block_index_t sbi;
          // call the function deque from multiheadQueue and use the lamda fuction as we want to make sure ethat t1.shred=t2.shred

    bool multi  = multiHeadQueue->dequeue(sbi,[](sb_block_index_t &t1, sb_block_index_t &t2)->bool{
        if(t1.shred == t2.shred){ //use the lamda fuction as we want to make sure ethat t1.shred=t2.shred
            return true;
         
     }
     
        else {
            return false;
        });

    
         // if the muti is true the loop will stop
    for(int i=0 ; multi == true ; i++)
    {
         Block *b = (*this)[sbi.shred_block];

       if() // print sbi_shred_block
       cout<<sbi.shred_block<<endl;
     // decryption 
        b->decrypt(key,iv);
       // call writeBlockat function from the filespooler and give it the the object we created from the class Block and sbi.block
        srcFileSpooler->writeBlockAt(b,sbi.block);
        
          // call the function deque from multiheadQueue and use the lamda fuction as we want to make sure ethat t1.shred=t2.shred

        multi = multiHeadQueue->dequeue(sbi,[](sb_block_index_t &t1, sb_block_index_t &t2)->bool{
            if(t1.shred == t2.shred){ //use the lamda fuction as we want to make sure ethat t1.shred=t2.shred
                return true;
                cout<<"TRUE"<<endl;
            }
            else{
                return false;
                cout<<"False"<<endl;
            });
        }
         // delete b
        delete(b);
    }
 
}

}
DecryptShredThread::~DecryptShredThread()
{
    
}
