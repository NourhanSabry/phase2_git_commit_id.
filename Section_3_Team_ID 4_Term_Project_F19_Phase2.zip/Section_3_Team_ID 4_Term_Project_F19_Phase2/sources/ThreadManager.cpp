#include <ThreadManager.h>

ThreadManager::ThreadManager(){

}

void ThreadManager::operator += (Thread * t){

    threads.push_back(t);
}
void ThreadManager::start ()

{
    //We made a loop to call every shred and start it.
    // In other words the for loop in the start function will call every shred and let every shred start his operation. 
for (auto s=threads.begin(); s!=threads.end(); s++){
s[0]-> start();
}
}
void ThreadManager::barrier (){
   // We made a similar for loop to call every thread in the vector,
   // but here the loop will call the wait function which will make every shred to wait for the others. 


for (auto s=threads.begin(); s! = threads.end(); s++){

s[0]-> wait();
}
}
 ThreadManager::~ThreadManager(){
}