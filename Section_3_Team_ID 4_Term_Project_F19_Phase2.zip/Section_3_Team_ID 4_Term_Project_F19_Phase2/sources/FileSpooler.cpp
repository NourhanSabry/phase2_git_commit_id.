#include <FileSpooler.h>

Block * FileSpooler::getBlockLockFree()
{
    Block * b = new Block (block_size);
    if (b->load(f)) return b;
    else {
        delete (b);
        return NULL;
    }
}


FileSpooler::FileSpooler(const char * p_file_name, uint16_t p_block_size, bool truncate)
{
    fsize = 0;
    if ( truncate )
        f.open(p_file_name,ios::in|ios::out|ios::trunc);
    else f.open(p_file_name,ios::in|ios::out);
    if ( f.is_open())
    {
        long cur = f.tellg ();
        f.seekg(0,f.end);
        fsize = f.tellg ();
        f.seekg(cur,f.beg);
    }
    block_size = p_block_size;
}
 Block * FileSpooler::operator [] (long index)
 {
    mtx.lock();
    if ( index*block_size >= fsize) 
    {
        mtx.unlock();
        return NULL;
    }
    long cur = f.tellg ();
    f.seekg(index*block_size,f.beg);
    Block * b  = getBlockLockFree();
    f.seekg(cur,f.beg);
    mtx.unlock();
    return b;
 }
long FileSpooler::getBlockCount () 
{

    //This function gets the block count to pass the number of blocks to lottery
    long remain = fsize % block_size;
    //Calculating the remainder from dividing the size of the file on the block size.
    long count = fsize / block_size; // Divide the size of the file on the block size to get the block count
    if(remain =! 0) //if the remainder not equal zero
    {
        count+=1; //Increment the count of blocks by one
    }
    return count;
}


Block * FileSpooler::getNextBlock()
{
    mtx.lock(); 
    Block * b  = getBlockLockFree();
    mtx.unlock ();
    return b;
}
void FileSpooler::appendBlock (Block * b)
{
    mtx.lock();
    b->store(f);
    mtx.unlock();
}
void FileSpooler::writeBlockAt(Block *b,long block_index) 
{

    mtx.lock(); //lock the file
    f.seekp(index*block_size, std::ios::beg); //set the position to the index multiplied by the block size
    b->store(); //call the store fuction to open the file and write in it
    mtx.unlock(); //unlock the file

}
FileSpooler::~FileSpooler()
{
    if ( f.is_open()) f.close();
}
