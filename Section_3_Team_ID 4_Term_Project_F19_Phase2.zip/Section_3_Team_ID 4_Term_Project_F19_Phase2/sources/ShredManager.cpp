#include <ShredManager.h>
#include <ThreadManager.h>
#include <MultiHeadQueue.h>
ShredManager::ShredManager () // added this in phase 2
{

}

ShredManager::ShredManager(char * p_file_name, uint16_t p_block_size, uint16_t p_shred_count,bool truncate)
{
    shred_count = p_shred_count;
    shreds = (Shred ** ) calloc (shred_count,sizeof(Shred*));
    for ( char i = 0 ; i  < shred_count; i++)
    {
        string fname = p_file_name;
        fname.insert(fname.find('.'),1,i+'A');
        cout << fname << endl;
        if (truncate)
            shreds[i] = new Shred(fname.c_str(),p_block_size,truncate);
        else shreds[i] = new Shred(fname.c_str(),(p_block_size+16)&~15,truncate);
    }
}
bool ShredManager::encrypt (FileSpooler * fileSpooler, const char * key_file_name, const char * iv_file_name)
{
   // key and IV setup
/*byte iv [AES::BLOCKSIZE];
memset(iv,0x00,AES::BLOCKSIZE)
byte key [AES::DEFAULTLENGTH];
memset(key,0x00,AES::DEFAULTLENGTH);
*/
// AES encryption uses a secret key of a variable length (128-bit, 196-bit or 256-   
    //bit). This key is secretly exchanged between two parties before communication   
    //begins. DEFAULT_KEYLENGTH= 16 bytes
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
     // read key
    ifstream kf; //Stream classes to read from the key file
    kf.open(key_file_name,ios::in); // the mode of the key file is in which enables the file to open for input operations
    if ( kf.is_open()) // To check if a file stream was successful opening a file. 
    {
        kf.read (reinterpret_cast<char*>(key),sizeof(key)); // read the key
        kf.close(); // we called the stream member function close to close it so that the operating system is notified and its resources become available again. 
    }
   // random generate block
    prng.GenerateBlock(iv,sizeof(iv));
    Block * block = fileSpooler->getNextBlock();
    for (int i = 0 ;block != NULL; i ++)
    {
        block->encrypt(key,iv);
        *(shreds[i%shred_count]) << *block;
        delete (block);
        block = fileSpooler->getNextBlock();
    }
    ofstream f;
    f.open(iv_file_name,ios::out|ios::trunc);
    if ( f.is_open())
    {
        f.write (reinterpret_cast<const char*>(iv),sizeof(iv));
        f.close();
    }
    return true;
}
bool ShredManager::decrypt (FileSpooler * fileSpooler, const char * key_file_name, const char * iv_file_name)
{
    AutoSeededRandomPool prng;
    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );
    ifstream f;
    f.open(key_file_name,ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(key),sizeof(key));
        f.close();
    }

    f.open(iv_file_name,ios::in);
    if ( f.is_open())
    {
        f.read (reinterpret_cast<char*>(iv),sizeof(iv));
        f.close();
    }

    Block * block = NULL;
    for (int i = 0 ; i == 0 || block != NULL; i ++)
    {
        block = shreds[i%shred_count]->getNextBlock();
        if ( block == NULL) break;
        block->decrypt(key,iv);
        //block->print();
        fileSpooler->appendBlock(block);
        delete (block);
    }
    return false;
}
ShredManager::~ShredManager()
{
    for ( int i = 0 ; i  < shred_count; i++)
        delete(shreds[i]);
    free(shreds);
}
//*************

MultithreadedShredManager::MultithreadedShredManager(char * p_file_name, uint16_t p_block_size, uint16_t p_shred_count,bool p_truncate) : ShredManager()
{
    file_name = p_file_name;
    shred_count = p_shred_count;
    block_size = p_block_size;
    truncate = p_truncate;
    shreds = (Shred ** ) calloc (shred_count,sizeof(Shred*));
}
bool MultithreadedShredManager::encrypt (FileSpooler * p_fileSpooler, char * key_file_name,  char * iv_file_name, char * q_file_name)
{
     //we create an object from the ThreadManager class
      ThreadManager * tm = new ThreadManager();
      // we  create an object from the Lottery class.
    Lottery * l= new Lottery  (p_fileSpooler->getNextBlock());
     // we  create an object from the MultiHeadQueue class.
    MultiHeadQueue <sb_block_index_t> * mq = new MultiHeadQueue <sb_block_index_t> () ;
    // IV setup 
 AutoSeededRandomPool prng;
    CryptoPP::byte iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );   
    // generate a random block
    prng.GenerateBlock(iv,sizeof(iv));
    // Stream class to write on files
    ofstream f;
    f.open(iv_file_name,ios::out|ios::trunc); //Open a file to read input and Truncate the existing file (default)
    if ( f.is_open())
    {
        f.write (reinterpret_cast<const char*>(iv),sizeof(iv)); //write iv
        f.close();
    }

    for ( int i = 0 ; i  < shred_count; i++)
    {
         //assigning the file name to another string.
        string fname = file_name;
        //naming the shred files with a,b,c.
        fname.insert(fname.find('.'),1,i+'A'); 
        cout << fname << endl;
        if (truncate)
        {
            //when truncate is true means in the encryption process.
        shreds[i] = new EncryptShredThread (p_fileSpooler, key_file_name, iv_file_name,fname.c_str() ,block_size,l ,mq,i+'A', truncate);
         //creating a EncryptShredThread in every loop with the same block size.
        }
        else {
            //when truncate is false means in the decryption process.

         shreds[i] = new EncryptShredThread (p_fileSpooler, key_file_name, iv_file_name,fname.c_str() ,block_size+16)&~15,l ,mq,i+'A', truncate);
            //creating a  EncryptShredThread in every loop with different block size as it changes after the encryption.
            //calling the operator in the threadmanager to pushback
        *tm += (reinterpret_cast<Thread*> (shreds[i] );
        }
        // calling the dump in the multiheadqueue
        mq->dump (q_filename,key_file_name,iv_file_name)
        // calling the start in the threadmanager 
        tm->start();
         // calling the barrir  in the threadmanager 
        tm->barrier();
        // deleting the object we craeted from the lottry 
        delete (l);
        // deleting the object we craeted from the multiheadqueue
         delete (mq);
         // deleting the object we craeted from the threadmanager
         delete (tm);
    return true;
}
bool MultithreadedShredManager::decrypt (FileSpooler * p_fileSpooler, char * key_file_name,  char * iv_file_name, char * q_file_name)
{
         //we create an object from the ThreadManager class

   ThreadManager * tm = new ThreadManager();
    //we create an object from the multiheadque class

    MultiHeadQueue <sb_block_index_t> * mq = new MultiHeadQueue <sb_block_index_t> () ;
    // calling the function load from the multiheadqueue
            mq->load (q_filename,key_file_name,iv_file_name)


    for ( int i = 0 ; i  < shred_count; i++)
    {
        string fname = file_name;
        fname.insert(fname.find('.'),1,i+'A');
           //naming the shred files with a,b,c
        cout << fname << endl;
        if (truncate)
        {
        shreds[i] = new DecryptShredThread  (p_fileSpooler, key_file_name, iv_file_name,fname.c_str() ,block_size,l ,mq,i+'A', truncate);
        //creating a DecryptShredThread in every loop with the same block size.
        }
        else {
           
         shreds[i] = new DecryptShredThread (p_fileSpooler, key_file_name, iv_file_name,fname.c_str() ,block_size+16)&~15,l ,mq,i+'A', truncate);
            //creating a  DecryptShredThread in every loop with different block size as it changes after the encryption.
            //calling the operator in the threadmanager to pushback
        *tm += (reinterpret_cast<Thread*> (shreds[i] );
        }
        // calling the start in the threadmanager 
        tm->start();
         // calling the barrir  in the threadmanager 
        tm->barrier();
                // deleting the object we craeted from the multiheadqueue

        delete (mq);
         // deleting the object we craeted from the threadmanager
         delete (tm);
    return true;
}

MultithreadedShredManager::~MultithreadedShredManager()
{

}
